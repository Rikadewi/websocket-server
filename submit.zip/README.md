# Simple Websocket Server


### Kelompok : Willukas's TCP
- 13517006 / Lukas Kurnia Jonathan
- 13517066 / Willy Santoso
- 13517147 / Rika Dewi

### Petunjuk Penggunaan Program
```
$ PORT={NOMOR_PORT} python3 server.py
```

### Pembagian Tugas
  | NIM      | Nama                  | Apa yang dikerjakan               | Kontribusi |
  |----------|-----------------------|-----------------------------------|------------|
  | 13517006 | Lukas Kurnia Jonathan | Handshake, Framing, Control Frame | 33.3 %     |
  | 13517066 | Willy Santoso         | Handshake, Framing, Control Frame | 33.3 %     | 
  | 13517147 | Rika Dewi             | Handshake, Framing, Control Frame | 33.3 %     |
